def sort_and_remove_duplicates(input_list):
    """Sort and remove duplicates from an input list of integers."""
    # Check if the input list is empty
    if len(input_list) == 0:
        return "This list is empty."

    # Sort and remove duplicates from the input list
    sorted_list = sorted(input_list)
    unique_list = []
    for num in sorted_list:
        if num not in unique_list:
            unique_list.append(num)

    return unique_list