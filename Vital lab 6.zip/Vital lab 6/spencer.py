import MyPackage
from MyPackage.sort_remove_dup import sort_and_remove_duplicates

# Get the input list from the user
input_list = input("Enter a list of integers, separated by commas: ").split(",")

# Convert the input string to a list of integers
input_list = [int(num.strip()) for num in input_list]

# Sort and remove duplicates from the input list
unique_list = sort_and_remove_duplicates(input_list)

# Print the sorted and unique list
print("Sorted and unique list:", unique_list)
